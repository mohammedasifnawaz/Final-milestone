import mysql.connector                                        ##here i import the mysqlconnector
import pyodbc                                                 ##here import the pyodbc driver
from mysql.connector import errorcode                         ##here include the connector

try:
   cm_connection = pyodbc.connect( "Driver={SQL Server};"
    "Server=DESKTOP-ED8GQ7K\MSSQLSERVER01;"                            ##here in connection to the database
    "Database=Beecolony;"                       
    "Trusted_Connection=yes;")
except pyodbc.connect.Error as e:                                      ## here include the authentication of the database
   if e.errno == errorcode.ER_ACCESS_DENIED_ERROR:
      print("credentials is Invalid")
   elif e.errno == errorcode.ER_BAD_DB_ERROR:
      print("no database")                                           ##if no database are available the this message will be printed
   else:
      print("can't: connect", e)                                     ## here is show the not connected  error message

else:
   print("Connection Sucessfull")
   my_cursor = cm_connection.cursor()
   task = 1
   while (task != 0):                                                 ##here is the option for choose which option you want to perform

      print ("............................................")
      print("1.  Press 1 for Exit")
      print ("2.  Press 2 for pull data Data")
      print("3.  Press 3 for inserted Data")
      # print("4.  Press 4 for  delete Data")
      print(".............................................")
      task = int(input("Enter your choice : "))

      if (task==2) :
         select_query = ("SELECT * FROM honey")                   ##here is the code for pull data from the database
         my_cursor.execute(select_query)
         for row in my_cursor.fetchall():
            print("{}   {} {} {} {} {} {} {}".format(row[0], row[1], row[2], row[3],row[4],row[5],row[6],row[7]))
      elif (task==3) :                                             ##here is the data added code
         State = input("Enter State")
         Honeyproducingcolonies = input("Enter Honeyproducingcolonies ")
         Yieldperolony = input("Enter Yieldperolony")
         Production = input("Enter Production")
         StocksDecember15 = input("Enter StocksDecember15")
         Averagepriceperpound = input("Enter Averagepriceperpound")
         Valueofproduction = input("Enter Valueofproduction")
         year=input("Enter Year")


         bee_query = ("INSERT INTO honey"
                           "(State,Honeyproducingcolonies,Yieldperolony,Production,StocksDecember15,Averagepriceperpound,Valueofproduction,year)"          
                           "VALUES (?,?,?,?,?,?,?,?)")

         bee_data = (State,Honeyproducingcolonies,Yieldperolony,Production,StocksDecember15,Averagepriceperpound,Valueofproduction,year)
         try:
            bee_cursor = cm_connection.cursor()
            bee_cursor.execute(bee_query, bee_data)
            cm_connection.commit()
            print("Bee data  added successfully")                             ##here is successfully message
            bee_cursor.close()
         except mysql.connector.Error as e:
          print("Bee data not added")
          print("Error: {}".format(e))



   cm_connection.close()